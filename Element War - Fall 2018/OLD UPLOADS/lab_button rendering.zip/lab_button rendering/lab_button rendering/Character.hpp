//
//  Character.hpp
//  Button Renderering
//
//  Created by Ali Shujjat on 20/11/2018.
//  Copyright © 2018 Ali Shujjat. All rights reserved.
//

#ifndef Character_hpp
#define Character_hpp

#include "SDL.h"
#include <stdio.h>
#include "LTexture.hpp"

class Character
{
private:
    int x,y;
    SDL_Rect charRect; 
	char shownChar; 
	LTexture* CharTexture;
    
public: Character ();
    Character(char c,LTexture* gSpriteSheetTexture);
    void Render(SDL_Renderer* gRenderer);
    void setPosition(int x, int y);
    void setChar(char c);
    void setTexture(LTexture* gSpriteSheetTexture , char c);
};

#endif /* Character_hpp */
