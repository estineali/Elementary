//
//  Word.hpp
//  Button Renderering
//
//  Created by Ali Shujjat on 20/11/2018.
//  Copyright © 2018 Ali Shujjat. All rights reserved.
//

#ifndef Word_hpp
#define Word_hpp

#include <stdio.h>
#include "LTexture.hpp"
#include "Character.hpp"
using namespace std;

class Word
{
private:
    int x,y;
    string renderWord;
    LTexture* TxtTexture;
    Character* characters;
	Word* word;
public:
    Word(std::string str,LTexture* gSpriteSheetTexture , int x , int y);
    void render(SDL_Renderer* gRenderer);
    void setText(string str);
    void setPosition(int x ,int y); 
	int getTextLength ();

};

#endif /* Word_hpp */
