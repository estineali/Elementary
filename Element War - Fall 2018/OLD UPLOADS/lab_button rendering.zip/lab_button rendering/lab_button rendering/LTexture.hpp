//
//  LTexture.hpp
//  Button Renderering
//
//  Created by Ali Shujjat on 20/11/2018.
//  Copyright © 2018 Ali Shujjat. All rights reserved.
//


#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>

//Texture wrapper class
class LTexture
{
private:
    SDL_Texture* texture; //The actual hardware texture
    int width;
    int height;
    
public:
    LTexture();                     //Initializes variables
    void free();
    ~LTexture();                    //Deallocates memory
    
    void render(int x, int y, SDL_Renderer* gRenderer, SDL_Rect* clip = NULL);
    //Renders texture at given point
    //Gets image dimensions
    bool LoadFromFile( std::string path, SDL_Renderer* gRenderer );
    int getWidth();
    int getHeight();
	void render_background(int x, int y, SDL_Renderer* gRenderer, SDL_Rect* clip);
    
};


