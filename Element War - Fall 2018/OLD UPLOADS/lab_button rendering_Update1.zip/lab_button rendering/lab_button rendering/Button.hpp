//
//  Button.hpp
//  Button Renderering
//
//  Created by Ali Shujjat on 20/11/2018.
//  Copyright © 2018 Ali Shujjat. All rights reserved.
//

//#ifndef Button_hpp
//#define Button_hpp





//
//  Button.hpp
//  Button Renderering
//
//  Created by Ali Shujjat on 20/11/2018.
//  Copyright Â© 2018 Ali Shujjat. All rights reserved.
//


#include <stdio.h>
#include "SDL.h"
#include <string>
#include "Word.hpp"
#include "LTexture.hpp"
#include "Position.h"

enum State{Normal, Hover, Clicked};
using namespace std;

class Button
{
private:
	int x, y;
	int width, height;
	SDL_Rect BtnRect[3];
	LTexture* btnTexture;
	int state;
	Word* word;
	std::string str;
	Position pos;
public:
	Button();
	Button(LTexture* Texture, string str, int x, int y);
	~Button();
	void render(SDL_Renderer* gRenderer);
	void setPosition(int x, int y);
	void set_width(int width);
	int get_width();
	void set_height(int height);
	int get_height();
	void setText(string str);
	void state_of_button(State);
	bool button_clicked();
	void operator= (const Button& cpy);
};





















/*
#include <stdio.h>
#include "SDL.h"
#include <string>
#include "Word.hpp"
#include "LTexture.hpp"

using namespace std;

class Button
{
private:
    int x, y;
    SDL_Rect BtnRect;
	SDL_Rect CharRect[3];
    LTexture* btnTexture;
	LTexture* charTexture;

public:
    Button(LTexture* Texture, LTexture* Texture2,string str,SDL_Renderer*,int x,int y, int w, int h);
    void render(SDL_Renderer* gRenderer, int x, int y);
    void setPosition(int x, int y);
    void setText(string str);
    Word* word;
};
*/

