//
//  Word.cpp
//  Button Renderering
//
//  Created by Ali Shujjat on 20/11/2018.
//  Copyright © 2018 Ali Shujjat. All rights reserved.
//

#include "Word.hpp"

Word::Word(std::string str, LTexture* gSpriteSheetTexture, int x, int y)
{
    this->TxtTexture = gSpriteSheetTexture;
    characters = NULL;
    setText(str);
    setPosition(x,y);
}

int Word::getTextLength()
{
    return this->renderWord.length();
}


void Word::setPosition(int x, int y) {
    this ->x = x;
    this ->y = y;
    
    for (int i = 0; i < this->renderWord.length(); i++)
    {
        characters[i].setPosition(x+i*88,y);
    }
    
}

void Word::render(SDL_Renderer* gRenderer)
{
    for (int i = 0; i < this->renderWord.length(); i++)
    {
        characters[i].Render(gRenderer);
    }
    
}

void Word::setText(string str) {
    this->renderWord = str;
	if (characters != NULL)
    {
        delete [] characters;
    }
    characters = new Character[str.length()];
    for (int i = 0; i < this->renderWord.length(); i++)
    {
        characters[i].setTexture(this->TxtTexture, str[i]);
		characters[i].setPosition(200, 200);
    }
}
