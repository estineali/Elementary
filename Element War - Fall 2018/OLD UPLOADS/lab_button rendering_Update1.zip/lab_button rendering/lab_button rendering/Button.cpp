//
//  Button.cpp
//  Button Renderering
//
//  Created by Ali Shujjat on 20/11/2018.
//  Copyright © 2018 Ali Shujjat. All rights reserved.
//


//
//  Button.cpp
//  Button Renderering
//
//  Created by Ali Shujjat on 20/11/2018.
//  Copyright Â© 2018 Ali Shujjat. All rights reserved.
//

#include "Button.hpp"
#include "LTexture.hpp"
#include "Word.hpp"
#include "SDL.h"
#include <string>
#include <cmath>
using namespace std;

Button::Button() {
	width = 0;
	height = 0;
	state = 0;
	word = NULL; 
}

Button::Button(LTexture* Texture, string str, int x, int y)
{
	this->word = new Word(str, Texture, x, y);
	this->btnTexture = Texture;
	for (int i = 0; i < 3; i++)
	{
		BtnRect[i].x = 88 * (i + 1);
		BtnRect[i].y = 99 * 5;
		BtnRect[i].w = 100;
		BtnRect[i].h = 99;
	}
	setPosition(x, y);
}

Button::~Button() {
	if (sizeof(word)!=0 )
	{
		word = NULL;
		delete word;
	}
}
void Button::render(SDL_Renderer* gRenderer) {
	btnTexture->render(this->x - ((word->getTextLength() / 2) + 1) * 88, this->y - 99 / 2, gRenderer, &BtnRect[0]);
	for (int i = 0; i < word->getTextLength(); i++)
	{
		btnTexture->render(this->x - (word->getTextLength() / 2) * 88 + ((i) * 88), this->y - 99 / 2, gRenderer, &BtnRect[1]);
	}
	word->render(gRenderer);
	btnTexture->render(this->x + ceil((double)word->getTextLength() / 2) * 88, this->y - 99 / 2, gRenderer, &BtnRect[2]);
	//btnTexture->render(this->x + 3 * 88, this->y - 99 / 2, gRenderer, &BtnRect[2]);
}



void Button::setPosition(int x, int y)
{
	this->x = x;
	this->y = y;
	this->word->setPosition(x - (word->getTextLength() / 2) * 88, y - 99 / 2);
}

void Button::set_width(int width) 
{
	this->width = width;
}
int Button::get_width()
{
	return width;
}


void Button::set_height(int height) 
{
	this->height = height;
}
int Button::get_height()
{
	return height;
}

void Button::setText(string str)
{
	word->setText(str);
	setPosition(x, y);
}

void Button::state_of_button(State value)
{
	state = value;
}


bool Button::button_clicked()
{
	std::cout << "Button is clicked" << std::endl;
	state = Clicked;
	return state;
}

void Button ::operator = (const Button& copy)
{
	state = copy.state;
	width = copy.width;
	height = copy.height;
	pos.x = copy.pos.x;
	pos.y = copy.pos.y;
	btnTexture = copy.btnTexture;
	word = copy.word;
	str = copy.str;
	BtnRect[Normal] = copy.BtnRect[Normal];
	BtnRect[Hover] = copy.BtnRect[Hover];
	BtnRect[Clicked] = copy.BtnRect[Clicked];
	this->word = new Word(str, btnTexture, pos.x, pos.y);
}















/*using namespace std;
Button::Button(LTexture* Texture, LTexture* Texture2,string str,SDL_Renderer* gRenderer ,int x, int y,int w,int h)
{
    this->word = new Word(str, Texture, 0, 0);
    this->btnTexture = Texture;
	this->charTexture = Texture2;

	btnTexture->LoadFromFile("images/ElementWarButton.png", gRenderer);
	BtnRect.x = x;
	BtnRect.y = y;
	BtnRect.h = h;
	BtnRect.w = w;

	setPosition(x, y);

	//charTexture->LoadFromFile("images/fontSprite.png", gRenderer);
	//NO NEED FOR THIS LOOP
    for (int i = 0; i < 3; i++)
    {
        CharRect[i].x = 44* (i+1);
		//CharRect[i].x = 200;
		CharRect[i].y = 1* 5;
		//CharRect[i].y = 300;
		//BtnRect[i].w = w;
		//BtnRect[i].h = h;
		//CharRect[i].w = word->getTextLength();  // want this 
		CharRect[i].w = 50;
		CharRect[i].h = 100;
    }
	setPosition(x, y);

	
}

void Button::setText(string str)
{
    word->setText(str);
    setPosition(x, y);
}

void Button::setPosition(int x, int y)
{
    this ->x = x;
    this ->y = y;
    this->word->setPosition(x - (word->getTextLength()/2)*88 ,y -99/2);
}
void Button::render(SDL_Renderer* gRenderer, int x, int y) {
	btnTexture->render(x, y, gRenderer, &BtnRect);
	//charTexture->render(200+(this->x - (word->getTextLength() / 2) + 1 * 88), 300+(this->y - 99 / 2), gRenderer, &CharRect[0]);
    //NO NEED FOR THIS LOOP
	for (int i = 0; i < word->getTextLength(); i++)
    {
        //charTexture->render(this->x - ((word->getTextLength()/2)*88 + ((i) * 88), this->y-99/2, gRenderer, &CharRect[1]);
		charTexture->render(200 + (this->x - (word->getTextLength() / 2) + 1 * 88), 300 + (this->y - 99 / 2), gRenderer, &CharRect[1]);
	}
    word->render(gRenderer);
    charTexture->render(this->x - ((word->getTextLength() / 2) + 1) * 88, this->y - 99 / 2, gRenderer, &CharRect[2]);
}
*/