#pragma once
struct Position
{
	float x;
	float y;
	Position(float p_x, float p_y)
	{
		x = p_x;
		y = p_y;
	}
	Position() {
		x = 0;
		y = 0;

	}

	Position(const Position& pos)
	{
		x = pos.x;
		y = pos.y;

	}

	bool operator = (Position pos)
	{
		this->x = pos.x;
		this->y = pos.y;
	}
};