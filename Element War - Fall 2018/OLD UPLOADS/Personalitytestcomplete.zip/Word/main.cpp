//
//  main.cpp
//  Button Renderering
//
//  Created by Ali Shujjat on 20/11/2018.
//  Copyright © 2018 Ali Shujjat. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include "Character.hpp"
#include "LTexture.hpp"
#include "Word.hpp"
#include "Button.hpp"
#include "SDL.h"
#include "SDL_image.h"
#include <string>
#include "PersonalityTest.h"

//Pre defined screen width and height
const int SCREEN_WIDTH = 1024;
const int SCREEN_HEIGHT = 760;

SDL_Window* gWindow = NULL;

SDL_Renderer* gRenderer = NULL;

LTexture gSpriteSheetTexture;

bool init()
{
    //Initialization flag
    bool success = true;

    //Initialize SDL
    if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
        success = false;
    }
    else
    {
        //Set texture filtering to linear
        if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
        {
            printf( "Warning: Linear texture filtering not enabled!" );
        }

        //Create window
        gWindow = SDL_CreateWindow( "Element War", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
        if( gWindow == NULL )
        {
            printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
            success = false;
        }
        else
        {
            //Create renderer for window
            gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
            if( gRenderer == NULL )
            {
                printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
                success = false;
            }
            else
            {
                //Initialize renderer color
                SDL_SetRenderDrawColor( gRenderer, 0, 0, 0, 0 );

                //Initialize PNG loading
                int imgFlags = IMG_INIT_PNG;
                if( !( IMG_Init( imgFlags ) & imgFlags ) )
                {
                    printf( "SDL_image could not initialize! SDL_mage Error: %s\n", IMG_GetError() );
                    success = false;
                }
            }
        }
    }

    return success;
}

bool loadMedia()
{
    //Loading success flag
    bool success = true;

    //Load sprite sheet texture
    if( !gSpriteSheetTexture.LoadFromFile( "wr.png", gRenderer  ) )
    {
        printf( "Failed to load sprite sheet texture!\n" );
        success = false;
    }

    return success;
}

void close()
{
    //Free loaded images
    gSpriteSheetTexture.Free();

    //Destroy window
    SDL_DestroyRenderer( gRenderer );
    SDL_DestroyWindow( gWindow );
    gWindow = NULL;
    gRenderer = NULL;

    //Quit SDL subsystems
    IMG_Quit();
    SDL_Quit();
}


Word** Testscreen(LTexture* r,PersonalityTest test)
{
    Word** Qarray = NULL;
    Qarray = new Word*[4];
    for(int i=0; i<4;i++)
    {
        Word* Ques1 = NULL;
        Ques1 = new Word[5];
        //Ques1[0] = Word btn(test.get_ques(1).get_quest(), &gSpriteSheetTexture, 985, 50);
        Word btn(test.get_ques(i).get_quest(), &gSpriteSheetTexture, SCREEN_WIDTH/2, 50);
        Ques1[0] = btn;
        Word option_a(test.get_ques(i).show_optiona(), &gSpriteSheetTexture, SCREEN_WIDTH/2 + 50, SCREEN_HEIGHT/2);
        Ques1[1] = option_a;
        Word option_b(test.get_ques(i).show_optionb(), &gSpriteSheetTexture, SCREEN_WIDTH/2 + 50,SCREEN_HEIGHT/2 + 50);
        Ques1[2] = option_b;
        Word option_c(test.get_ques(i).show_optionc(), &gSpriteSheetTexture, SCREEN_WIDTH/2+50,SCREEN_HEIGHT/2 + 100);
        Ques1[3] = option_c;
        Word option_d(test.get_ques(i).show_optiond(), &gSpriteSheetTexture, SCREEN_WIDTH/2+50,SCREEN_HEIGHT/2+150);
        Ques1[4] = option_d;
        Qarray[i] = Ques1;
    }
    return Qarray;

}
void Rendering(SDL_Event events,PersonalityTest test,LTexture* r, Word** Ques1)
{
    bool quit = false;
    int i = 0;
        while(!quit)
        {
            while( SDL_PollEvent( &events ) != 0 )
            {
                if(events.type == SDL_QUIT)
                {
                    quit = true;
                }
                if(events.type == SDL_KEYDOWN)
                {
                    if(events.key.keysym.sym == SDLK_a)
                    {
                        i+=1;
                        test.increment_test_score(10);
                    }
                    else if (events.key.keysym.sym == SDLK_b)
                    {
                        i+=1;
                        test.increment_test_score(20);
                    }
                    else if(events.key.keysym.sym == SDLK_c)
                    {
                        i+=1;
                        test.increment_test_score(30);
                    }
                    else if(events.key.keysym.sym == SDLK_d)
                    {
                        i+=1;
                        test.increment_test_score(40);
                    }
                }

                if (i>3)
                {
                    i=0;
                    test.increment_test_score(-test.get_test_score());
                }
                Word* Arr = NULL;
                SDL_SetRenderDrawColor(gRenderer, 0, 0, 0, 0 );
                SDL_RenderClear( gRenderer );
                Arr = Ques1[i];
                Arr[0].Render(gRenderer);
                Arr[1].Render(gRenderer);
                Arr[2].Render(gRenderer);
                Arr[3].Render(gRenderer);
                Arr[4].Render(gRenderer);
                SDL_RenderPresent( gRenderer );
            }
        }
}
int main(int argc, char* args[] )
    {
        PersonalityTest test;
        if(init())
        {
            if(loadMedia())
            {
                SDL_Event events;
                //char*  ans,ques,ques2,ques3,ans2,ans3;
                Word** Qarray = NULL;
                Qarray = Testscreen(&gSpriteSheetTexture, test);
                //Ques2 = TestScreen(&gSpriteSheetTexture, test)
            Rendering(events, test,&gSpriteSheetTexture, Qarray);
               // Rendering(events, test,&gSpriteSheetTexture,);
            }
        }
        close();
        return 0;
    }

