//
//  Button.cpp
//  Button Renderering
//
//  Created by Ali Shujjat on 20/11/2018.
//  Copyright © 2018 Ali Shujjat. All rights reserved.
//

/*#include "Button.hpp"
#include "LTexture.hpp"
#include "Word.hpp"
#include "SDL.h"
#include <string>
using namespace std;

Button::Button(LTexture* Texture, string str, int x, int y)
{
    this->word = new Word(str, Texture, x, y);
    this->btnTexture = Texture;
    for (int i = 0; i < 3; i++)
    {
        BtnRect[i].x = 88 * (i+1);
        BtnRect[i].y = 99 * 5;
        BtnRect[i].w = 1500;
        BtnRect[i].h = 99;
    }
    setPosition(x, y);
}


void Button::setText(string str)
{
//    word->setText(str);
    setPosition(x, y);
}

void Button::setPosition(int x, int y)
{
    this ->x = x;
    this ->y = y;
//    this->word->setPosition(x - (word->getTextLength()/2)*88 ,y -99/2);
}
void Button::render(SDL_Renderer* gRenderer) {
//    btnTexture->render(this->x-((word->getTextLength()/2)+1)*88, this->y-99/2, gRenderer, &BtnRect[0]);
    for (int i = 0; i < word->getTextLength(); i++)
    {
        btnTexture->render(this->x - (word->getTextLength()/2)*88 + ((i) * 88), this->y-99/2, gRenderer, &BtnRect[1]);
    }
    word->render(gRenderer);
    btnTexture->render(this->x + (word->getTextLength())/2 * 88, this->y-99/2, gRenderer, &BtnRect[2]);
}
*/
