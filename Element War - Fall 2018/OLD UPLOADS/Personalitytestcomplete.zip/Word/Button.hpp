//
//  Button.hpp
//  Button Renderering
//
//  Created by Ali Shujjat on 20/11/2018.
//  Copyright © 2018 Ali Shujjat. All rights reserved.
//

#ifndef Button_hpp
#define Button_hpp

#include <stdio.h>
#include "SDL.h"
#include <string>
#include "Word.hpp"
#include "LTexture.hpp"

using namespace std;

class Button
{
private:
    int x, y;
    SDL_Rect BtnRect [3];
    LTexture* btnTexture;

public:
    Button(LTexture* Texture, string str, int x, int y);
    void render(SDL_Renderer* gRenderer);
    void setPosition(int x, int y);
    void setText(string str);
    Word* word;
};
#endif /* Button_hpp */
