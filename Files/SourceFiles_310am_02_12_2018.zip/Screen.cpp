#include "Screen.h"

//Abstract Class

/*-CTORS*/
Screen::Screen()
{
	std::cout << "Screen Constructor Called" << std::endl;
}

Screen::~Screen()
{
	std::cout << "Screen Virtual Destructor Called" << std::endl;
}


